package com.better.alarm.ui.timepicker

data class PickedTime(val hour: Int, val minute: Int)
